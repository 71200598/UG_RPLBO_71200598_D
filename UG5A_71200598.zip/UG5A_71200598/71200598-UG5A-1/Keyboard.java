public class Keyboard {
    String merkModel;
    long harga;

    void setMerkModel(String merkModel){
        this.merkModel=merkModel;
    }
    String getMerkModel(){
        return merkModel;
    }
    void setHarga(long harga){
        this.harga=harga;
    }
    long getHarga(){
        return harga;
    }


}