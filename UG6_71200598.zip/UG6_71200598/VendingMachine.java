import java.util.ArrayList;

public class VendingMachine {
    String code;
    int capacity;
    int usedCapacity;
    ArrayList goods = new ArrayList(Goods);
    ArrayList acceptanceBalance = new ArrayList(double);
    double consumerMoney;

    public VendingMachine(){}

    public VendingMachine(String code,int capacity){
        this.code=code;
        this.capacity=capacity;
    }
    Goods gg = new Goods();
    public VendingMachine(String code,int capacity,gg goods,double[] acceptanceBalance){
        this.code=code;
        this.capacity=capacity;
        this.goods=goods;
        this.acceptanceBalance=acceptanceBalance;
    }

}
