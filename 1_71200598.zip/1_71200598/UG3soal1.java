import java.util.Scanner;

public class UG3soal1 {
    public static void main(String[] args) {
        String nama;
        String tgl;
        int jml;
        int brt;

        Scanner scan = new Scanner(System.in);
        System.out.println("=======Data Product========");
        System.out.print("Nama Makanan : ");
        nama = scan.nextLine();
        System.out.print("Tanggal Kadaluarsa : ");
        tgl = scan.nextLine();
        System.out.print("Jumlah (quantity) : ");
        jml = scan.nextInt();
        System.out.print("Berat (gram) : ");
        brt = scan.nextInt();

        System.out.println();
        System.out.println("=======Data Product========");
        System.out.println("Nama Makanan : "+nama);

        System.out.println("Tanggal Kadaluarsa : "+tgl);

        System.out.println("Jumlah (quantity) : "+jml);

        System.out.println("Berat (gram) : "+brt);

    }
}
