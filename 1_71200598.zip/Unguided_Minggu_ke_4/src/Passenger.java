public class Passenger {
    String name;
    double balance;
    String email;
    String Destiny;

    public Passenger(String name,String email,double balance){
        setName(name);
        setEmail(email);
        setBalance(balance);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setDestiny(String destiny) {
        Destiny = destiny;
    }

    public String getDestiny() {
        return Destiny;
    }
}
