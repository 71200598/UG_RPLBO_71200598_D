public class TransPay {
    String nama;
    long saldo;
    Keyboard key = new Keyboard();

    void setNama(String nama){
        this.nama=nama;
    }
    String getNama(){
        return nama;
    }
    void setSaldo(long saldo){
        this.saldo=saldo;
    }
    long getSaldo(){
        return saldo;
    }
    void topUp(long topup){
        if(getSaldo()>0){

        this.saldo=this.saldo+topup;
            System.out.println("Top up sebesar "+getSaldo()+" berhasil");}
        else{
            System.out.println("Top Up Gagal");
        }
    }
    void bayar(int jumlah,key k){
        long byr = jumlah * k.getHarga();
        if (byr<0){
            System.out.println("Pembayaran input Jumlah invalid");
        }else if (getSaldo()>byr){
            System.out.println("Pembayaran Sukses! Silahkan mengambil "+k.getMerkModel());
            sal=getSaldo()-byr;
            setSaldo(sal);
        }else{
            System.out.println("Saldo Kurang");
        }
    }
}