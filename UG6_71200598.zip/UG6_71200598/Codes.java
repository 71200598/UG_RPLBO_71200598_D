public class Codes {
    private String GOODSCODES = "GD";
    private String VENDINGMACHINESCODE="VD";
    private String[] TYPE={"DR","FD","DG"};

    String generateGoodsCode(String type, String name){
        char pertama = name.charAt(0);
        char terakhir = name.charAt(name.length());

        if(type == "makanan"){
            return GOODSCODES+TYPE[1]+String(pertama)+String(terakhir);
        }else if(type=="minuman"){
            return GOODSCODES+TYPE[0]+String(pertama)+String(terakhir);
        }else{
            return GOODSCODES+TYPE[2]+String(pertama)+String(terakhir);
        }

    }

    String generateVendingMachinesCode(int order){
        return VENDINGMACHINESCODE+String(order)
    }
}
