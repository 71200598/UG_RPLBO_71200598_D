public class Driver {
    String name;
    int age;
    String gender;

    public Driver(String name,String gender,int age){
        setAge(age);
        setGender(gender);
        setName(name);
    }

    String getName() {return name;}
    int getAge() {return age;}
    String getGender() {return gender;}
    void setName(String name){
        this.name=name;
    }
    void setAge(int age){
        this.age=age;
    }
    void setGender(String gender){
        this.gender=gender;
    }

}
