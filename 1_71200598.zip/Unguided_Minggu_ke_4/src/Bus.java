import java.util.ArrayList;
public class Bus {
    String name;
    Driver driver;
    private int Capacity;

    final ArrayList<Passenger> passenger = new ArrayList<Passenger>();
    int usedCapacity;
    final double fares=15000;
    double profit;
    String[] ROUTE;

    public Bus(String name,Driver driver){
        setName(name);
        setDriver(driver);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setCapacity(int capacity) {
        Capacity = capacity;
    }

    public int getCapacity() {
        return Capacity;
    }

    public ArrayList<Passenger> getPassenger() {
        return passenger;
    }

    public void setUsedCapacity(int usedCapacity) {
        this.usedCapacity = usedCapacity;
    }

    public int getUsedCapacity() {
        return usedCapacity;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

    public double getProfit() {
        return profit;
    }

    public void setROUTE(String[] ROUTE) {
        this.ROUTE = ROUTE;
    }

    public String[] getROUTE() {
        return ROUTE;
    }

    public double getFares() {
        return fares;
    }
    boolean checkPassengerBalance(Passenger passenger){
        if (passenger.getBalance()>0){
            return true;
        }else{
            return false;
        }
    }
    void topUpBalance(double topup,Passenger passenger){
        passenger.setBalance(topup);
    }

}
